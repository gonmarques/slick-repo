#!/bin/sh
docker build -t oracle/serverjre:8 .
